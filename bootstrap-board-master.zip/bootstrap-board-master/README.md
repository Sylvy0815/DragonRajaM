# 부트스트랩 XE 게시판 스킨
## 개요
부트스트랩 CSS/JS를 활용한 게시판 스킨입니다.

## 설치법
/modules/board/skins/bootstrap_board 에 설치하시면 됩니다.

## 문의사항
이곳 저장소에 이슈 제출해 주세요.
